% This is an example of using the simulator EsophagealCancerSim.m, although
% that function is already quite self-explanatory.

clear, clc

% BE patient whose risk is 0.08, aspirin effect is 0.4, statin effect is
% 0.2 and age is 55, chooses to use no drug (0);
% Run the simulator for 10000 replications;
% Do not use control variate (CV) to reduce variance in simulation (0);
% Output the sample mean of the simulated quality-adjusted life years (QALY);
QALY = EsophagealCancerSim(0.08,0.4,0.2,0,55,10000,0)

% Choose to use aspirin
% Output both the sample mean and sample variance (not the variance of
% sample mean!)
QALY_mean_var = EsophagealCancerSim(0.08,0.4,0.2,1,55,10000,0,'mean_var')

% Use (CV) to reduce variance in simulation (1); can obsreve that the
% sample variace is smaller
QALY_mean_var = EsophagealCancerSim(0.08,0.4,0.2,1,55,10000,1,'mean_var')

% Choose to use statin 
% Output all the sample points of QALY (10000 points)
QALY_sample = EsophagealCancerSim(0.08,0.4,0.2,2,55,10000,1,'raw');