function y = fun(x)

% minimize -> maximize
y = - Dock(x,1);

end