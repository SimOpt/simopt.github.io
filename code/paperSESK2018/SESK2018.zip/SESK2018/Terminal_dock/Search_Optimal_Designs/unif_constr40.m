function x_in = unif_constr40()

n = 40;
M = 111;

x1L = 5; x1H = 24;
x2L = 61; x2H = 80;
x3L = 5;  x3H = 24;
x4L = 21; x4H = 40;
LH = [x1L x1H; x2L x2H; x3L x3H; x4L x4H];

x_in = [];
while size(x_in,1) < n
    x = zeros(n*10,4);
    for i = 1:4
        x(:,i) = randi(LH(i,:),n*10,1);
    end
    index = sum(x,2) <= M;
    x_in2 = x(index,:);
    
    x_in = [x_in; x_in2];   
    x_in = unique(x_in,'rows');  % remove the duplication
end

x_in = x_in(1:n,:);
end