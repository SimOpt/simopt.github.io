% stylized model 2 - fluid approximation

function waiting_time = stylized2(s)   %%% weighted average waiting time

% Non stationary Poisson Arrival
% arrival rate/h, 00-01, 01-02, ..., 23-24
arrival_rate = ...
[16	11	13	3	4	7	22	40	9	6	3	6	7	6	6	19	22	27	7	22	20	26	15	16; ...
 41	41	39	35	28	39	31	59	61	63	65	56	63	65	64	71	64	75	52	56	65	56	53	43; ...
 2	0	1	1	0	1	3	3	1	18	14	12	19	17	25	15	15	6	7	5	19	8	3	4; ...
 65	56	67	55	59	46	30	24	21	13	15	9	12	9	10	15	21	27	30	43	44	42	52	66];

% % distribution of service time,              % unit: min
% service_dist{1} = 'wblrnd(21.8, 1.3)';       % mean (21.8/1.3)*gamma(1/1.3)
% service_dist{2} = '7 + wblrnd(67.6, 1.5)';   % mean 7 + (67.6/1.5)*gamma(1/1.5)
% service_dist{3} = '7 + gamrnd(0.9, 25.7)';   % mean 7 + 0.9 * 25.7
% service_dist{4} = '7 + gamrnd(3.0, 9.4)';    % mean 7 + 3.0 * 9.4
% 60 ./ [(21.8/1.3)*gamma(1/1.3), 7 + (67.6/1.5)*gamma(1/1.5), 7 + 0.9 * 25.7, 7 + 3.0 * 9.4]

% transfer to service rate / hour
mu = [2.9800, 0.8820, 1.9914, 1.7045];

%%%% Fluid parameter
h = 0.005;
T = 24*3;
T0 = 24*2;

app_waiting = zeros(1,4);
for docki = 1:4

    arrival_rate1 = arrival_rate(docki,:);
    mu1 = mu(docki);  % unit: rate / hour
    s1 = s(docki);

    % discretize lam_t by interval h
    t_grid = h:h:T;
    lam_grid = ceil(rem(t_grid,24));
    lam_grid((lam_grid == 0)) = 1;
    lamt = arrival_rate1(lam_grid);

    X = zeros(1,length(t_grid)+1);
    a = 0;
    b = 0;
    for i = 1:length(t_grid)
        a = a + lamt(i) * h;
        b = b + mu1 * min(s1, X(i)) * h;
        X(i+1) = a - b;
    end
    X(1) = [];
%     plot(t_grid, X, 'r-');


    %%%%% waiting time after warm-up time T0
    % calculate the arrival time point
    arrival_point = [];
    for i=1:24
        arrival_point = [arrival_point, (i-1) + (1:arrival_rate1(i))/arrival_rate1(i)];
    end

    tW = 0;
    k = 0;
    for i = 1:length(arrival_point)
        t_index = round( (T0 + arrival_point(i)) / h);  
        L = X(t_index);

        % waiting time for this arrival
        if L <= s1-1
            W = 0;
        else
            W = (L-s1+1)/(s1*mu1);
        end  
        if t_index*h + W + 1/mu1 <= T   % this customer finish service before T
            tW = tW + W;
            k = k+1;
        end
    end    
    app_waiting(docki) = tW/k * 60;  %unit: min
end

tot = [333, 1285, 199, 831];  % total arrival # for one day
waiting_time = app_waiting * tot' / sum(tot);

end