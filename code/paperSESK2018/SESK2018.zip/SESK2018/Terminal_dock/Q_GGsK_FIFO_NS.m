function [time_record, num_record, clock_state] = Q_GGsK_FIFO_NS(SimPra, QueuePra)
%========================== function statement ===========================
% this is one single Gt/G/s/K station. The arrival process is non-stationary

% Output
% time_record - averaged waiting time in the Queue vs departure customers for each replication
%               Note: only consider the customers ever enter the station, 
%               i.e., the rejected customers are not counted.
%              (can be modified to count all arrivals)     
%              (can also be easily changed to the sojourn time in the station)
% num_record - averaged number of customers in the station
%              (can also be easily changed to the number waitting in queue)
% clock_state - the detailed clock & state process for each replication

% Input - SimPra
% T           % time length for one replication
% T0          % warm up length to let the queue be steady
% simR        % number of simulation replication
% seed        % control the random stream

% Input - QueuePra
% arrival_rate - non-stationary poisson arrival rate
% s - server number 
% servicetimeRV - service time distribution
% K - capacity (wating space + server number)
%==========================================================================

T = SimPra.T;
T0 = SimPra.T0;
simR = SimPra.simR;
seed = SimPra.seed;  

if ~isempty(seed)
    s_pseudo = RandStream('mt19937ar','Seed',seed);
    RandStream.setGlobalStream(s_pseudo);
end

arrival_rate = QueuePra.arrival_rate;
lam_max = max(arrival_rate);          
s = QueuePra.s;
servicetimeRV = QueuePra.servicetimeRV;
K = QueuePra.K;

% tic
time_record = zeros(simR,2);  % record the average Waiting (or Sojourn) time vs departure number for each replication
num_record = zeros(simR,1);   % record the average customer number in System (or Queue) for each replication
clock_state = cell(simR,2);   % recodr the detailed clock & state for each replication
% pre allocate size for other recorder
pre_size = round(lam_max*2*T*1.5);   % 1.5 safe factor

for repi = 1:simR    
%     fprintf('%d  \n',repi); 
    
    % the time point of first arrival
    %%% generate the non-stationary Poisson Arrival (thinning method)
    customerclock = -log(rand)/lam_max;    
    h = floor(rem(customerclock,24))+1;
    lam = arrival_rate(h);
    while rand > lam/lam_max
        customerclock = customerclock -log(rand)/lam_max;
        h = floor(rem(customerclock,24))+1;
        lam = arrival_rate(h);
    end    
    
    serverclock = inf(s,1); % initially no server will finish (empty system)
    serverreg = zeros(s,1); % keep the customer ID in each server of each station
    if s < K && K < inf
        queuereg = zeros(K-s,1);     % keep the customer ID in the queue
        customer_rec = zeros(K,2,3); % temporarily save customer information
    elseif K == inf
        queuereg = zeros(100,1);
        customer_rec = zeros(100,2,3);  
    end
    
    myclock = 0;
    state = 0;          % simulation start with empty system, NOT from steady state           
    clock_rec = zeros(pre_size,1);
    clock_rec(1) = myclock;    
    if K < 256
        state_rec = uint8(zeros(pre_size,1));  % to save memory
    else
        state_rec = zeros(pre_size,1);
    end
    state_rec(1) = state;
    rec_index = 1;          
    sojourn = zeros(2,1); % record the total sojourn time and customer number inside one replication
        
    while myclock <= T  
        [myclock, min_loc] = min([customerclock; serverclock]);
        
        if min_loc == 1  % customer arrive       
            if state < K % when system is not full, enter the system; otherwise leave
                state = state + 1;                              
                % repeatly use the unoccupied ID;
                % it will not keep the depatured customer in record
                ID = find(customer_rec(:,1,1)==0, 1); 
                if isempty(ID)
                    ID = size(customer_rec,1) + 1;
                end                                               
                customer_rec(ID,1:2,1) = [ID, 2];   % the customer enters the system
                      
                if state <= s   % NOT all servers were serving before, new server starts to work 
                    si = find(serverclock==inf,1);  % assign an empty server                         
                    serverclock(si) = myclock + eval(servicetimeRV);  % the time clock of next server finish
                    customer_rec(ID,1:2,2) = [myclock, si];  % at time 'mylock', customer ID enters server 'si'
                    serverreg(si) = ID;                      % regist in server
                else
                    customer_rec(ID,1:2,2) = [myclock, 0];   % at time 'mylock', customer ID enter the queue
                    queue_l = state - s;
                    queuereg(queue_l) = ID;           % regist in queue
                end
            end
            
            % the time point of next customer (inverse of exponential)
            customerclock = customerclock -log(rand)/lam_max;
            h = floor(rem(customerclock,24))+1;
            lam = arrival_rate(h);
            while rand > lam/lam_max
                customerclock = customerclock -log(rand)/lam_max;
                h = floor(rem(customerclock,24))+1;
                lam = arrival_rate(h);
            end                     
            
        else
            
            si = min_loc - 1;   % find out the finish server
            ID1 = serverreg(si);                              
            ID_depth = customer_rec(ID1,2,1);
            
            % calculate the total sojourn time and counter the departure numbers
            if customer_rec(ID1,1,2) > T0 && myclock <= T 
                
                %%%% calculate sojourn time in system
                % sojourn = sojourn + [myclock - customer_rec(ID1,1,2); 1];
                
                %%%% calculate waiting time in queue
                if ID_depth == 3                                             
                    sojourn = sojourn + [customer_rec(ID1,1,3) - customer_rec(ID1,1,2); 1];
                else
                    sojourn = sojourn + [0; 1];
                end
            end
            % clear the customer_rec entry
            customer_rec(ID1,1:2,1:ID_depth) = 0;
                      
            queue_l = state - s;
            state = state - 1;
            if state < s  % this server will be empty (the queue was empty before)
                serverclock(si) = inf;
                serverreg(si) = 0;
            else          % this server will be occupied by next customer
                serverclock(si) = myclock + eval(servicetimeRV);  % the time clock of next server finish              
                ID2 = queuereg(1);
                ID_depth = customer_rec(ID2,2,1)+1;
                customer_rec(ID2,2,1) = ID_depth;                    
                customer_rec(ID2,1:2,ID_depth) = [myclock, si];                     

                serverreg(si) = ID2;
                if queue_l > 1
                    queuereg(1:queue_l-1) = queuereg(2:queue_l);                       
                end
                queuereg(queue_l) = 0;
            end      
        end
        rec_index = rec_index+1;
        clock_rec(rec_index) = myclock;
        state_rec(rec_index) = state;         
    end
      
    %%% keep record of average sojourn time in station <for thoese ever enter the system>
    time_record(repi,:) = [sojourn(1)/sojourn(2), sojourn(2)];    
    
    
%     % only keep the valid record
%     clock_rec = clock_rec(1:rec_index);  
%     state_rec = state_rec(1:rec_index);    
%     % throw the warmup length
%     a = length(clock_rec);       
%     h0 = find(clock_rec > T0,1);
%     clock_rec = [T0; clock_rec(h0:a)];   % to be accurate, the interested time point is right at warmup_length    
%     state_rec = state_rec(h0-1:a,:);          
% 
%     %%% keep record of the clock and state
%     clock_state{repi,1} = clock_rec;
%     clock_state{repi,2} = state_rec;
   
%     %%% keep record of average customer # in each station 
%     a = length(clock_rec);   
%     inter_rec = clock_rec(2:a-1) - clock_rec(1:a-2);
%     inter_rec(a-1) = T - clock_rec(a-1);
%     num_record(repi) = inter_rec' * double(state_rec(1:end-1)) / (T-T0);     
      
end
% toc

% % mean and variance of customer number
% N_var = [mean(num_record); var(num_record)]

% % mean and variance of sojourn time
% T_var = [mean(time_record(:,1)); var(time_record(:,1))]
