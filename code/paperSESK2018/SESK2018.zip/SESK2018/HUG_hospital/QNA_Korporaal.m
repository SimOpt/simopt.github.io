function W = QNA_Korporaal(c)

J = 9;
gam = [0.39 0.5 0.25 0.06 0.18 0.03 0.13 0.16 0];

mu = [0.32 0.26 0.34 0.01 0.02 0.01 0.02 0.22 0.52];
P = [ 0   0   0  .16 .02  0   0  .71  0 ; ...
      0   0   0  .07  0   0   0  .84  0 ; ...
      0   0   0  .03 .01  0   0   0  .95; ...
     .18 .01 .03  0  .03 .01 .11 .03  0 ; ...
     .05 .01 .01 .01  0  .07  0   0   0 ; ...
     .02  0   0  .01 .1   0   0   0   0 ; ...
     .05  0  .05 .04  0   0   0  .01  0 ; ...
      0   0   0   0   0   0  .01  0   0 ; ...
      0   0   0  .05  0   0  .05 .02  0 ];

% (i) initialization
N = c*P;
p_loss_new = zeros(1,J);
% p_loss_new = ones(1,J) * 0.5;
stepsize = 1;
iter = 0;
s = c;

% apply function to each element of array (row vector)
interp_Q_v = @(gam,lam,mu,s,N)arrayfun(@interp_Q,gam,lam,mu,s,N);
interp_p_v = @(gam,lam,mu,s,N)arrayfun(@interp_p,gam,lam,mu,s,N);
interp_pI_v = @(gam,lam,mu,s,N)arrayfun(@interp_pI,gam,lam,mu,s,N);
interp_L_v = @(gam,lam,mu,s,N)arrayfun(@interp_L,gam,lam,mu,s,N);


while stepsize > 10^-6
    
    p_loss = p_loss_new;
    
    % (ii) updata parameters
    % 1
    throughput = gam .* (1-p_loss) / (eye(J)-P);

    % 2 M(gam)-M(lam)/M(mu)/s/s+N
    lam = throughput*P;
    
    % 3
    s = c - throughput .* sum(P .* repmat(interp_Q_v(gam,lam,mu,s,N) ./ throughput, J,1) ,2)';

    % 4
    p_loss_new = interp_p_v(gam,lam,mu,s,N);
    
    % (iii) check stop condition
    stepsize = max(abs(p_loss_new - p_loss));
    
    iter = iter+1;
    if iter >= 100
        warning('Fail to Converge!');
        break;
    end
end

% (iv) modify the service rate 
p_loss_I = interp_pI_v(gam,lam,mu,s,N);
t = 1 ./ mu;
for repi = 1:8
    for i = 1:J
        for j = 1:J
            if P(i,j)>0
                t(i) = t(i) + p_loss_I(j)*lam(j)/(mu(j)*s(j)*throughput(i));
            end
        end
    end  
end
mu = 1 ./ t;

% total number in network
L = sum(interp_L_v(gam,lam,mu,s,N));

% total external entering rate
enter_rate = gam * (1-p_loss_new)';

% sojourn time in system, little's law
W = L/enter_rate;
end


% interpolate p_loss when s or N is not-integer
function p_loss_I = interp_pI(gam,lam,mu,s,N)
su = ceil(s);
sl = floor(s);
Nu = ceil(N);
Nl = floor(N);
if su <= 0
    error('Error! Server Number is Negative!');
elseif sl == 0
    sl = sl+1;
    su = su+1;
end
distslNl = M_MMsN_dist(gam,lam,mu,sl,Nl); % [state 0 is not included!]
distsuNl = M_MMsN_dist(gam,lam,mu,su,Nl);
distslNu = M_MMsN_dist(gam,lam,mu,sl,Nu);
distsuNu = M_MMsN_dist(gam,lam,mu,su,Nu);

if sl == su % i.e., s is integer
    alpha = 0.5;
else
    alpha = (s-su)/(sl-su);
end
p_lossNl = alpha*distslNl(sl+Nl) + (1-alpha)*distsuNl(su+Nl);
p_lossNu = alpha*distslNu(sl+Nu) + (1-alpha)*distsuNu(su+Nu);
if Nl == Nu % i.e., N is integer
    alpha = 0.5;
else
    alpha = (N-Nu)/(Nl-Nu);
end
p_loss_I = alpha*p_lossNl + (1-alpha)*p_lossNu;
end

% interpolate p_loss when s or N is not-integer
function p_loss = interp_p(gam,lam,mu,s,N)
su = ceil(s);
sl = floor(s);
Nu = ceil(N);
Nl = floor(N);
if su <= 0
    error('Error! Server Number is Negative!');
elseif sl == 0
    sl = sl+1;
    su = su+1;
end
distslNl = M_MMsN_dist(gam,lam,mu,sl,Nl); % [state 0 is not included!]
distsuNl = M_MMsN_dist(gam,lam,mu,su,Nl);
distslNu = M_MMsN_dist(gam,lam,mu,sl,Nu);
distsuNu = M_MMsN_dist(gam,lam,mu,su,Nu);

if sl == su % i.e., s is integer
    alpha = 0.5;
else
    alpha = (s-su)/(sl-su);
end
p_lossNl = alpha*sum(distslNl(sl:sl+Nl)) + (1-alpha)*sum(distsuNl(su:su+Nl));
p_lossNu = alpha*sum(distslNu(sl:sl+Nu)) + (1-alpha)*sum(distsuNu(su:su+Nu));
if Nl == Nu % i.e., N is integer
    alpha = 0.5;
else
    alpha = (N-Nu)/(Nl-Nu);
end
p_loss = alpha*p_lossNl + (1-alpha)*p_lossNu;
end

% interpolate L when s or N is not-integer
function L = interp_L(gam,lam,mu,s,N)
su = ceil(s);
sl = floor(s);
Nu = ceil(N);
Nl = floor(N);
if su <= 0
    error('Error! Server Number is Negative!');
elseif sl == 0
    sl = sl+1;
    su = su+1;
end
if sl == su % i.e., s is integer
    alpha = 0.5;
else
    alpha = (s-su)/(sl-su);
end
LNl = alpha*M_MMsN_L(gam,lam,mu,sl,Nl) + (1-alpha)*M_MMsN_L(gam,lam,mu,su,Nl);
LNu = alpha*M_MMsN_L(gam,lam,mu,sl,Nu) + (1-alpha)*M_MMsN_L(gam,lam,mu,su,Nu);
if Nl == Nu % i.e., N is integer
    alpha = 0.5;
else
    alpha = (N-Nu)/(Nl-Nu);
end
L = alpha*LNl + (1-alpha)*LNu;
end

% number of all customers in M(gam)-M(lam)/M(mu)/s/s+N
function L = M_MMsN_L(gam,lam,mu,s,N)
% s>=1, N>=0, both integers

dist = M_MMsN_dist(gam,lam,mu,s,N); % [state 0 is not included!]
% total number 
L = (1:s+N) * dist';  
end

% interpolate Q when s or N is not-integer
function Q = interp_Q(gam,lam,mu,s,N)
su = ceil(s);
sl = floor(s);
Nu = ceil(N);
Nl = floor(N);
if su <= 0
    error('Error! Server Number is Negative!');
elseif sl == 0
    sl = sl+1;
    su = su+1;
end
if sl == su % i.e., s is integer
    alpha = 0.5;
else
    alpha = (s-su)/(sl-su);
end
QNl = alpha*M_MMsN_Q(gam,lam,mu,sl,Nl) + (1-alpha)*M_MMsN_Q(gam,lam,mu,su,Nl);
QNu = alpha*M_MMsN_Q(gam,lam,mu,sl,Nu) + (1-alpha)*M_MMsN_Q(gam,lam,mu,su,Nu);
if Nl == Nu % i.e., N is integer
    alpha = 0.5;
else
    alpha = (N-Nu)/(Nl-Nu);
end
Q = alpha*QNl + (1-alpha)*QNu;
end

% number of waiting customers in M(gam)-M(lam)/M(mu)/s/s+N
function Q = M_MMsN_Q(gam,lam,mu,s,N)
% s>=1, N>=0, both integers

dist = M_MMsN_dist(gam,lam,mu,s,N); % [state 0 is not included!]
% number of waiting
if N == 0
    Q = 0;
else
    Q = max((1:s+N) - s, 0) * dist';  
end
end

% stationary dist of M(gam)-M(lam)/M(mu)/s/s+N
function dist = M_MMsN_dist(gam,lam,mu,s,N) % [state 0 is not included!]
% s>=1, N>=0, both integers

ss = sum(((gam+lam)/mu) .^ (0:s) ./ factorial(0:s));
if N >= 1
    ss = ss + ((gam+lam)/mu)^s/factorial(s) * sum((lam/(s*mu)).^(1:N));
end

dist = zeros(1,s+N);
dist0 = 1/ss;
dist(1:s) = dist0 * ((gam+lam)/mu) .^ (1:s) ./ factorial(1:s);
if N >= 1
    dist(s+1:s+N) = dist0 * ((gam+lam)/mu)^s/factorial(s) * (lam/(s*mu)).^(1:N);
end
end