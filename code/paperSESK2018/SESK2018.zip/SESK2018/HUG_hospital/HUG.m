function SimT_var = HUG (s,setting,seed)

simR = setting.simR;
T0 = setting.T0;
T = setting.T;

% simR = 10;  % Generate observation
% T0 = 10000;
% T = 50000;

% simR = 50;  % Generate "Truth"
% T0 = 10000;
% T = 50000;


J = 9;
lam = [0.39 0.5 0.25 0.06 0.18 0.03 0.13 0.16 0];
% s = [4 8 5 18 18 4 4 10 6];
mu = [0.32 0.26 0.34 0.01 0.02 0.01 0.02 0.22 0.52];
P = [ 0   0   0  .16 .02  0   0  .71  0 ; ...
      0   0   0  .07  0   0   0  .84  0 ; ...
      0   0   0  .03 .01  0   0   0  .95; ...
     .18 .01 .03  0  .03 .01 .11 .03  0 ; ...
     .05 .01 .01 .01  0  .07  0   0   0 ; ...
     .02  0   0  .01 .1   0   0   0   0 ; ...
     .05  0  .05 .04  0   0   0  .01  0 ; ...
      0   0   0   0   0   0  .01  0   0 ; ...
      0   0   0  .05  0   0  .05 .02  0 ];
K = s;

% find all the closed loop in the network
% use a third-party function "find_elem_circuits"
% author: Chris Maes  https://gist.github.com/cmaes/1260153
% moreover, the function "find_elem_circuits" relies on a function
% "components", which is a function in the graph package MatlabBGL
% author: David Gleich  http://dgleich.github.io/matlab-bgl 
Q = (P~=0);
addpath ./third_party_function
addpath ./third_party_function/matlab_bgl_4.0.1_private             
[CircleN,CircleList] =  find_elem_circuits(Q);



SimPra.seed = seed;
SimPra.T = T;
SimPra.T0 = T0;
SimPra.simR = simR;
QueuePra.J = J;
QueuePra.lam = lam;
QueuePra.s = s;
QueuePra.mu = mu;
QueuePra.P = P;
QueuePra.K = K;
QueuePra.CircleList = CircleList;

[~, SimT_var] = QN_GGsK_BAS_FIFO(SimPra, QueuePra);

% for i=1:9
% 	subplot(3,3,i);
%     plot(0:length(SimP{i})-1, cumsum(SimP{i}),'s');
% end

end





