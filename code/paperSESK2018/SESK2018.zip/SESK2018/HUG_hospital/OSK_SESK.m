clear; clc; close all;
addpath ../SKDec122009/SK_code_version1_1229;
addpath ..

kriging_type = 0;
% 0, Ordinary Stochastic Kriging (OSK)
% 1, Stylized-Model Enhanced Stochastic Kriging (SESK)

%%% Predicted points
x1 = [3 5];
x2 = [3 13];
x3 = [3 7];
x4 = [8 18 28];
x5 = [8 18 28];
x6 = [3 5];
x7 = [3 5];
x8 = [5 15];
x9 = [3 9];

[X1,X2,X3,X4,X5,X6,X7,X8,X9] = ndgrid(x1,x2,x3,x4,x5,x6,x7,x8,x9);
XK = [X1(:) X2(:) X3(:) X4(:) X5(:) X6(:) X7(:) X8(:) X9(:)];
K = size(XK,1);

% load the "true" response value
% to see how it is obtained, see script Generate_True_Sojourn_Time.m
load('y_true.mat')


%%% Observed points
c = [4 8 5 18 18 4 4 10 6]; % current configuration
X = repmat(c,23,1);
X(2,1) = 2; X(3,1) = 6;
X(4,2) = 4; X(5,2) = 12;
X(6,3) = 2; X(7,3) = 8;
X(8,4) = 10; X(9,4) = 14; X(10,4) = 22; X(11,4) = 26;
X(12,5) = 10; X(13,5) = 14; X(14,5) = 22; X(15,5) = 26;
X(16,6) = 2; X(17,6) = 6;
X(18,7) = 2; X(19,7) = 6;
X(20,8) = 6; X(21,8) = 14;
X(22,9) = 2; X(23,9) = 10;
k = size(X,1); 

% Y = zeros(k,1);
% Vhat = zeros(k,1);
% % For reproducibility, arbitrarily fix a random seed. Besides, in this way,
% % there is no CRN.
% s_pseudo = RandStream('mt19937ar','Seed',2);
% RandStream.setGlobalStream(s_pseudo); 
% for i = 1 : size(X,1)
%     fprintf('%d  \n',i);
%     s = X(i,:);    
%     setting.simR = 10;
%     setting.T0 = 10000;
%     setting.T = 50000;
%     tic
%     SimT_var = HUG (s,setting,[]);
%     toc
%     % average run time: 240s (4min) on MATLAB R2015a
%     % Windows 7 Enterprise 64-bit Operating System
%     % Interl Core i7-3770 CPU @ 3.40GHz, 8 GB RAM
%     Y(i,1) = SimT_var(1,10);
%     Vhat(i,1) = SimT_var(2,10);
% end
load('Y_Vhat.mat');




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
switch (kriging_type)
    case 0 % OSK, constant trend term
        BK = ones(K,1);
        B = ones(k,1);

    case 1 % SESK        
        refK = zeros(K,1);
%         for i=1:K
%             x = XK(i,:);
%             refK(i,1) = QNA_Korporaal(x);
%         end
        load('refK.mat')
        
        % calculate RMSE MAPE if the stylized model is directly used as prediction
        RMSE_stylized = sqrt(sum((refK - y_true).^2)/length(y_true));
        MAPE_stylized = sum(abs((refK - y_true) ./ y_true))/length(y_true); 
        
        ref = zeros(k,1);
        for i=1:k
            x = X(i,:);
            % tic
            ref(i) = QNA_Korporaal(x);
            % toc
            % average run time: 0.06s on MATLAB R2015a
            % Windows 7 Enterprise 64-bit Operating System
            % Interl Core i7-3770 CPU @ 3.40GHz, 8 GB RAM
        end
        BK = [ones(K,1) refK];
        B = [ones(k,1) ref];

end

% === >>> SK fit and predict:
% stochastic kriging with constant trend (q=0), 
% gammaP correlation function, 1-exponential, 2-gauss, 3-cubic
gammaP = 2;
skriging_model = SKfit(X,Y,B,Vhat,gammaP);
SK  = SKpredict(skriging_model,XK,BK);
RMSE = sqrt(sum((SK - y_true).^2)/length(y_true));
MAPE = sum(abs((SK - y_true) ./ y_true))/length(y_true);


% === >>> print parameters:
printSK (skriging_model);
fprintf('RMSE = %.3f; \n',RMSE);
fprintf('MAPE = %.5f; \n',MAPE);


%%%%%%%%% plot out one profile
%%% plot points
c2 = [4 8 5 18 14 4 4 10 6];
x4range = 8:28;
i = 0;
for x4 = x4range
    x = c2;
    x(4) = x4;
    i = i+1;
    Xplot(i,:) = x;  
end
Kplot = length(x4range);
% generate yplot
% for i = 1:Kplot
%     x = Xplot(i,:);    
%     setting.simR = 100;
%     setting.T0 = 10000;
%     setting.T = 50000;
%     SimT_var = HUG (x,setting,0);
%     yplot(i) = SimT_var(1,10);
% end
load('yplot.mat');

%%% Observed points
i = 0;
for x4 = x4range
    x = c2;
    x(4) = x4;
    row = find(ismember(X,x,'rows'));
    if ~isempty(row)
        i = i+1;
        xobs(i) = x4;
        Yobs(i) = Y(row);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
switch (kriging_type)
    case 0 % OSK, constant trend term
        BKplot = ones(Kplot,1);
    case 1 % SESK       
        for i=1:Kplot
            x = Xplot(i,:);
            refKplot(i,1) = QNA_Korporaal(x);
        end
        BKplot = [ones(Kplot,1) refKplot];
end
[SKplot, MSEplot] = SKpredict(skriging_model,Xplot,BKplot);



% === >>> plot SK fitted surface:
figure;
set (gcf,'Position',[500,500,520,300])
plot(x4range,yplot,'*','LineWidth',1,'Color',[31,119,180]/255); hold on;
plot(xobs,Yobs,'o','Color',[255,127,14]/255);
plot(x4range,SKplot,'k--','LineWidth',1);
% MSE
plot(x4range,SKplot+1.96*sqrt(MSEplot),':','LineWidth',0.8,'Color',[214,39,40]/255);
h1 = plot(x4range,SKplot-1.96*sqrt(MSEplot),':','LineWidth',0.8,'Color',[214,39,40]/255); 

% add ref
if kriging_type == 1 
    plot(x4range,refKplot,'+','Color',[44,160,44]/255);
end

% figure format
axis([-inf inf 26 40]);
xlabel('$x_4$','Interpreter','latex');
ylabel('Mean sojourn time (hr.)','Interpreter','latex');
% set(gca,'XTick',7:29)

set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
switch (kriging_type)
    case 0 % OSK, constant trend term
        ht = legend({'True response','Mean simulation output',...
            'Fitted surface of OSK','$\pm 1.96 \sqrt{\widehat{\mathrm{MSE}}}$ intervals',...
            },'Location','north'); %,'FontSize',11
    case 1 % SESK 
        ht = legend({'True response','Mean simulation output',...
            'Fitted surface of SESK','$\pm 1.96 \sqrt{\widehat{\mathrm{MSE}}}$ intervals',...
            'Stylized model'},'Location','north');   
end
set(ht,'Interpreter','latex','color','none');


% %%% save data, plot in python
% MSE_po = SKplot+1.96*sqrt(MSEplot);
% MSE_ne = SKplot-1.96*sqrt(MSEplot);
% x4range = x4range';
% % save('HUG_plot_1.mat','x4range','yplot','xobs','Yobs','SKplot','MSE_po','MSE_ne');
% save('HUG_plot_2.mat','x4range','yplot','xobs','Yobs','SKplot','MSE_po','MSE_ne','refKplot');
