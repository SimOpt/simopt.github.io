clear; clc; close all;
addpath ../SKDec122009/SK_code_version1_1229;

% expected number of customers of M/M/1 (including the customer in service)
% arrival rate is x
% service rate is 1

%%% Predicted points
XK = (0.01:0.01:0.99)';
% -- trend term (constant) --
BK = ones(size(XK));

% Draw the true curve
XK2 = XK;
true = XK2 ./ (1-XK2);

%%% Observed points
X = [0.1; 0.3; 0.5; 0.7; 0.9];
Y = X./(1-X);
% covariance matrix (simulation noise)
Vhat = zeros(length(X),1);
% -- trend term (constant) --
B = ones(size(X));


% === >>> SK fit and predict:
% stochastic kriging with constant trend (q=0), 
% gammaP correlation function, 1-exponential, 2-gauss, 3-cubic
gammaP = 2;
skriging_model_2 = SKfit(X,Y,B,Vhat,gammaP);
[SK_gau, MSE] = SKpredict(skriging_model_2,XK,BK);
    
% === >>> plot SK fitted surface:
figure;
set (gcf,'Position',[500,500,520,300])
plot(XK2,true,'-','LineWidth',1,'Color',[31,119,180]/255); hold on;
plot(X,Y,'o','Color',[31,119,180]/255);
plot(XK,SK_gau,'k--','LineWidth',1);
% MSE
plot(XK,SK_gau+1.96*real(sqrt(MSE)),':','LineWidth',0.8,'Color',[214,39,40]/255);
h1 = plot(XK,SK_gau-1.96*real(sqrt(MSE)),':','LineWidth',0.8,'Color',[214,39,40]/255); 

% figure format
axis([0 1 -3 14]);
xlabel('$x$','Interpreter','latex');
ylabel('Expected number of customers','Interpreter','latex');
set(gca,'YTick',[-3 0 3 6 9 12])

ht = legend({'True surface','Observed value',...
    'Fitted surface of ordinary kriging','$\pm 1.96 \sqrt{\widehat{\mathrm{MSE}}}$ intervals'},'Location','northwest');
set(ht,'Interpreter','latex','color','none');


% %%% save data, plot in python
% MSE_po = SK_gau+1.96*real(sqrt(MSE));
% MSE_ne = SK_gau-1.96*real(sqrt(MSE));
% save('MM1_plot.mat','XK2','true','X','Y','XK','SK_gau','MSE_po','MSE_ne');