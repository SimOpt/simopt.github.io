function printSK (model)

betahat = model.beta;
tau2hat = model.tausquared;
thetahat = model.theta;
log_likelihood = -model.negLL;
statistic = model.statistic;
% statistic = [AIC, BIC] or [AIC, BIC, Z, pV]
AIC = statistic(1);
BIC = statistic(2);
if length(statistic)>2
    Z = statistic(3);
    pV = statistic(4);
end

fprintf('\n');
if length(betahat) == 1
    fprintf('--- Ordinary Stochastic Kriging ---');
else
    fprintf('--- Stylized-Model Enhanced Stochastic Kriging ---');
end
fprintf('\n');
fprintf('betahat = ');
if length(betahat)>1
    fprintf('[');
end
for i=1:length(betahat)
    fprintf('%.4f; ',betahat(i));
end
if length(betahat)>1
    fprintf(']');
end
fprintf('\n');
fprintf('tau2hat = %.4f;  \n',tau2hat);
fprintf('thetahat = ');
if length(thetahat)>1
    fprintf('[');
end
for i=1:length(thetahat)
    if thetahat(i) > 10000
        fprintf('%.2e; ',thetahat(i));
    else
        fprintf('%.4f; ',thetahat(i));
    end
end
if length(thetahat)>1
    fprintf(']');
end
fprintf('\n');
fprintf('log-likelihood = %.4f;  \n', log_likelihood);
fprintf('AIC = %.4f;  \n',AIC);
fprintf('BIC = %.4f;  \n',BIC);
if length(statistic)>2
    fprintf('Usefullness Test: Z = %.4f,  P_Value = %.4f;  \n',Z,pV);
end
end