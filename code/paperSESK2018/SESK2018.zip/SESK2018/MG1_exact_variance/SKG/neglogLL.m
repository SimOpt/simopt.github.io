function [f, beta, A] = neglogLL(parms,X,YD,B,Sigma)

% negative of log profile likelihood  
% This is a function of theta and tau2.
% we have profiled out over beta

% parms = [tau2;theta] 
% X - design points (k x d) 
% YD - simulation output mean (response and derivatives)
% B - basis functions
% Sigma - intrinsic covariance matrix
% k - number of design points
% d - dimension of design variables


[k, d] = size(X);
tau2 = parms(1);
theta = parms(2:d+1);


% given all parameters, calculate Gamma.
% correlation function: exponential
Gamma = zeros(k*(d+1));
for i = 0 : d
    for ii = 1 : k
        rown = i * k + ii;
        for j = 0 : d
            for jj = 1 : k
                coln = j * k + jj;
                % i,j = 0,1,2,...,d coordinate; ii,jj = 1,2,...,k point
                if i == 0 && j == 0
                    Gamma(rown,coln) = C(X(ii,:),X(jj,:),tau2,theta);
                elseif i == 0
                    Gamma(rown,coln) = 2*theta(j)*(X(ii,j)-X(jj,j)) * C(X(ii,:),X(jj,:),tau2,theta);
                elseif j == 0
                    Gamma(rown,coln) = 2*theta(i)*(X(jj,i)-X(ii,i)) * C(X(ii,:),X(jj,:),tau2,theta);
                elseif i == j
                    Gamma(rown,coln) = 2*theta(i)*(1-2*theta(i)*(X(ii,i)-X(jj,i))^2) * C(X(ii,:),X(jj,:),tau2,theta);
                else % i ~= j
                    Gamma(rown,coln) = -4*theta(i)*theta(j)*(X(ii,i)-X(jj,i))*(X(ii,j)-X(jj,j)) * C(X(ii,:),X(jj,:),tau2,theta);
                end
            end 
        end
    end
end

A = Sigma + Gamma;
BAinv = B' / A;
beta = (BAinv*B) \ (BAinv*YD);
f = 0.5*k*log(2*pi) + 0.5*log(det(A)) + 0.5*(YD-B*beta)'/A*(YD-B*beta);
end


function C00 = C(x1,x2,tau2,theta)
% correlation for response surface
% correlation function: exponential
C00 = tau2 * exp(- (x1 - x2).^2 * theta);
end