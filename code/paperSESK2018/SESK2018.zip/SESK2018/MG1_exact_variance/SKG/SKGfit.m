function model = SKGfit(X,Ycell,Dcell,B)
% fit a gradient enhancing stochastic kriging model to simulation output

% k - number of design points
% d - dimension of design variables
% X - design points (k x d) 
% n - (k x 1) vector, ni=[n1; n2; ..., nk], replication number
% Ycell - (k x 1) cell, each is a (1 x ni) vector, containing ni replications of Y
% Dcell - (k x 1) cell, each is a (d x ni) matrix about a points.
%          row 1, deriative wrt 1st coordinate for ni replications, ..., 
%          row d, deriative wrt d-th coordinate for ni replications


[k, d] = size(X);
n = zeros(1,k);
for i = 1:k
    n(i) = length(Ycell{i});
end

% Note: for kriging with gradient, normalization is NOT applicable!

% calculate sample covariance matrix, and use it as "true" value (Sigma)
Sigma = zeros(k*(d+1));
for i = 0 : d
    for ii = 1 : k
        rown = i * k + ii;
        for j = 0 : d
            for jj = 1 : k
                coln = j * k + jj;
                if rown == coln % diagonal of Sigma
                    if i == 0 % diagonal of covariance matrix of Y
                        Sigma(rown,coln) = var(Ycell{ii}) / n(ii);
                    else % diagonal of covariance matrix of D
                         % i = 1,2,...,d coordinate; ii = 1,2,...,k point
                        Sigma(rown,coln) = var(Dcell{ii}(i,:)) / n(ii);
                    end
                else
                    if ii == jj
                        % i,j = 0,1,2,...,d coordinate; ii = 1,2,...,k point
                        if i == 0
                            cov_temp = cov(Ycell{ii}, Dcell{ii}(j,:));
                        elseif j == 0
                            cov_temp = cov(Dcell{ii}(i,:), Ycell{ii});
                        else
                            cov_temp = cov(Dcell{ii}(i,:), Dcell{ii}(j,:));
                        end
                        Sigma(rown,coln) = cov_temp(1,2) / n(ii);
                    end
                end
            end 
        end
    end
end

% calculate sample mean of response and gradient
YD = zeros(k*(d+1),1);
for i = 0 : d
    for ii = 1 : k
        rown = i * k + ii;
        if i == 0
            YD(rown) = mean(Ycell{ii});
        else
            YD(rown) = mean(Dcell{ii}(i,:));
        end
    end
end

% initialize parameters tau2, theta (beta included)
% inital extrinsic variance = variance of ordinary regression residuals
betahat = (B'*B)\(B'*YD);
tau2_0 = var(YD-B*betahat);
theta_0 = log(2) ./ ((max(X) - min(X)).^2)';

% lower bounds for parameters tau2, theta
% only to satisfy fmincon  
lbtau2 = 0.001*tau2_0;     % naturally 0 
lbtheta = 0.001*ones(d,1); % naturally 0; increase to avoid numerical trouble
lb = [lbtau2;lbtheta];

% maximize log-likelihood function (-"neglogLL")
% subject to lower bounds on tau2 and theta
myopt = optimset('Display','iter','MaxFunEvals',1000000,'MaxIter',500);
parms = fmincon(@(x) neglogLL(x,X,YD,B,Sigma),...
        [tau2_0;theta_0],[],[],[],[],lb,[],[],myopt); 

% record MLEs for tau2 and theta 
tau2hat = parms(1);
thetahat = parms(2:length(parms));
% theta, A(=Sigma+Gamma) is computed in neglogLL
[~, betahat, A] = neglogLL(parms,X,YD,B,Sigma);

% issue warnings related to constraints 
warningtolerance = 0.001;
if min(abs(lbtheta - thetahat)) < warningtolerance
    warning('thetahat was very close to artificial lower bound');
end
if abs(lbtau2 - tau2hat) < warningtolerance
    warning('tau2hat was very close to artificial lower bound');
end

% output MLEs and other things useful in prediction
model.tausquared = tau2hat;
model.theta = thetahat;
model.beta = betahat;
model.X = X;
model.A = A;
model.B = B;
model.YD = YD;
end