# -*- coding: utf-8 -*-

from shutil import copyfile
import json
import subprocess
import os

# 将原setting.json文件复制备份
copyfile("setting.json", "setting_original_backup.json")   

# 读出原setting.json文件中的信息
with open("setting.json",'r', encoding='utf-8') as setting:
    setting_dict = json.load(setting)
setting.close()

randomSeed_temp = setting_dict['randomSeed']
directFlag_temp = setting_dict['directFlag']

setting_dict['directFlag'] = bool(True)

# 10次重复实验，令随机种子从0遍历到9
for randomSeed in range(10):
    print('随机种子取%d，' % randomSeed, end='')
    setting_dict['randomSeed'] = randomSeed
    with open("setting.json",'w',encoding='utf-8') as setting:
        json.dump(setting_dict, setting)
    setting.close()    
    
    sim_run = subprocess.Popen("AGV系统仿真平台Beta.exe")
    sim_run.wait()
    print('仿真运行完毕，结果已保存。')    

# 重置原setting.json文件
setting_dict['randomSeed'] = randomSeed_temp
setting_dict['directFlag'] = directFlag_temp
with open("setting.json",'w',encoding='utf-8') as setting:
    json.dump(setting_dict, setting)
setting.close()  

# 删除备份文件
os.remove("setting_original_backup.json")
