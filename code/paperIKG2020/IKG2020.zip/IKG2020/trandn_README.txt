The function trandn.m is a  third-party function downloaded from

Zdravko Botev (2020). Truncated Normal Generator (https://www.mathworks.com/matlabcentral/fileexchange/53180-truncated-normal-generator), MATLAB Central File Exchange. Retrieved June 29, 2020.

Reference
Botev, Z. I. (2016). "The normal law under linear restrictions: simulation and estimation via minimax tilting". Journal of the Royal Statistical Society: Series B (Statistical Methodology). doi:10.1111/rssb.12162