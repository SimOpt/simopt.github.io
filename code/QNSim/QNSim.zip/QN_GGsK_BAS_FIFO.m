function [SimP, SimN_var, SimQ_var, SimT_var, SimW_var] = QN_GGsK_BAS_FIFO(SimPra, QueuePra)
%========================== function statement ===========================
% This is a network of G/G/s/K station. The blocking policy is Blocking
% After Service (BAS), and the queue discipline FIFO - first in first out, 
% which is also known as first come first served (FCFS) in operating system.

% Output
% SimP - stationary distribution for each station
%        SimP{1} = [P0, P1, ... PK], SimP{2} ...

% SimN_var - averaged number of customers in each station & the whole system
%            and the variance of the AVERAGED number
%            SimN_var =   E1          E2      ...  EJ   E_whole
%                       var1/simR  var2/simR  ...       var/simR
% Note: It includes the customers waiting in the queue + customers under 
% service + customers who have finished service but still occupy the server
% because the destination station is full.

% SimQ_var - averaged number of customers in queue of each station & the
%            whole system (waiting) and the variance of the AVERAGED number
%            SimQ_var =   E1          E2      ...  EJ   E_whole
%                       var1/simR  var2/simR  ...       var/simR
% Note: Customers who have finished service but still occupy the server 
% because the destination station is full are not included.

% SimT_var - averaged sojourn time in each station & the whole system
%            and the variance of the AVERAGED number
%            SimN_var =   T1          T2      ...  TJ   T_whole
%                       var1/simR  var2/simR  ...       var/simR
% SimW_var - averaged waiting time in queue of each station & the whole system
%            and the variance of the AVERAGED number
%            SimN_var =   T1          T2      ...  TJ   T_whole
%                       var1/simR  var2/simR  ...       var/simR
% Note: When calculating the averaged sojourn time and waiting time, only 
% consider the customers ever enter the system and leave the system before 
% simulation terminates, i.e., the rejected customers are not counted; 
% the customers who are still in the system when simulation terminates are 
% not counted. Besides, if a customer never enters station 1, he will not 
% be counted when calculating averaged sojourn time for station 1. (It is 
% not difficult to modify the code to count all arrivals.) If a customer 
% enters station 1 more than once, he is still regarded as one customer.   


% Input - SimPra
% T - time length for one replication
% T0 - warm up length to let the queue be steady
% simR - number of simulation replication
% seed - control the random stream

% Input - QueuePra
% J - total station number
% lam - poisson arrival rate to each station [row vector]
% s - server number at each station [row vector]
% mu - exponential service rate of a server (all same) in each station [row vector]
% P - routing probabilities [matrix], i.e., P=[P11 P12; P21 P22]
% K - capacity (wating space + server number) of each station [row vector]
% CircleList - the list of all loops of the network (where the deadlock may happen)

% Note: when deadlock happens, simply swap the entities in that loop.
%==========================================================================

seed = SimPra.seed;
T = SimPra.T;
T0 = SimPra.T0;
simR = SimPra.simR;

J = QueuePra.J;
lam = QueuePra.lam;
s = QueuePra.s;
mu = QueuePra.mu;
P = QueuePra.P;
K = QueuePra.K;
CircleList = QueuePra.CircleList;

if ~isempty(seed)
    s_pseudo = RandStream('mt19937ar','Seed',seed);
    RandStream.setGlobalStream(s_pseudo);
end

% tic
state_at_T = zeros(simR,J);
% clock_state_record = cell(1,simR);
time_sojourn_record = zeros(simR,J+1);
time_waiting_record = zeros(simR,J+1);
num_record = zeros(simR,J+1);
num_record_queue = zeros(simR,J+1);

% pre allocate size for some variable
RV_n = round(T*max(lam)*2);

for repi = 1:simR   
%     fprintf('%d  \n',repi);
    
    % +++++++++++++ to speed up, generate the R.V. at a batch +++++++++++++
    inter_arrival_time_RV = inf(RV_n,J);
    service_time_RV = zeros(RV_n,J);
    for j=1:J
        inter_arrival_time_RV(:,j) = inter_arrival_time(j,RV_n,lam);
        service_time_RV(:,j) = service_time(j,RV_n,mu);
    end
    inter_arrival_point = ones(1,J);
    service_time_point = zeros(1,J);
    % +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    customerclock = inter_arrival_time_RV(1,:); % the time point of first arrival    
    finishclock = inf(1,J);      % initially no station will finish [simulation start with empty system, NOT from steady state]    
    serverclock = inf(max(s),J); % initially no server will finish
    serverreg = zeros(max(s),J); % keep the customer ID in each server of each station
    
    % keep the customer ID in the queue
    % if some station has infinite buffer, assign space 100 at this moment.
    buffersize = K-s;
    buffersize(buffersize==inf) = 100;
    if max(buffersize) > 0
        queuereg = zeros(max(buffersize),J);
    end
    
    % temporarily save customer information
    if max(K) < inf
        customer_rec = zeros(sum(K),3,J*5);
    else
        customer_rec = zeros(100,3,J*5);
    end        

    myclock = 0;
    state = zeros(1,J);          % [simulation start with empty system, NOT from steady state]   
    BlockList = cell(1,J);
    block_open = 0;
    known_destination = 0;
   
    pre_size = RV_n;
    clock_rec = zeros(pre_size,1);
    clock_rec(1) = myclock;    
    if max(K) < 256
        state_rec = uint8(zeros(pre_size,J));  % to save memory
    else
        state_rec = zeros(pre_size,J);
    end
    state_rec(1,:) = state;
    rec_index = 1;          

    sojourn = zeros(2,J+1);  % record the cumulative sojourn time and customer number
                             % for each station, and the whole system    
    waiting = zeros(2,J+1);  % record the cumulative waiting time and customer number
                             % for each queue, and the whole system (waiting) 
                             
    while myclock <= T
        
        if block_open > 0            
            % If this station was blocking some other station before, release one               
            if ~isempty(BlockList{block_open}) % some station was blocked by station 'loc' -> let it move                  
                Blocked_loc = BlockList{block_open}(1,1);    % station                   
                Blocked_si = BlockList{block_open}(1,2);     % server                   
                BlockList{block_open}(1,:) = [];             % remove from the Block list                  
                serverclock(Blocked_si,Blocked_loc) = myclock; % the blocked server is released immediately! (next iteration)
                known_destination = block_open;
                finishclock(Blocked_loc) = min(abs(serverclock(1:s(Blocked_loc),Blocked_loc)));     % update station finish lock                
            end 
            block_open = 0;
        else       
        
        [myclock, min_loc] = min([min(customerclock) min(finishclock)]);   
        
        % ++ case 1 ++ new customer arrives
        if min_loc == 1     
            [~, loc] = min(customerclock);  % find out the arrival station          
            if state(loc) < K(loc)          % when that station is not full, enter the system; otherwise leave
                state(loc) = state(loc) + 1;
                               
                % repeatly use the unoccupied ID;
                % it will not keep the depatured customer in record                
                ID = find(customer_rec(:,1,1)==0, 1); 
                if isempty(ID)
                    ID = size(customer_rec,1) + 1;
                end                  
                customer_rec(ID,1:3,1) = [ID, -1, 2];   % the customer enters the system                
                              
                if state(loc) <= s(loc)   % NOT all servers were serving before, new server starts to work                   
                    si = find(serverclock(1:s(loc),loc)==inf,1);  % assign an empty server                         
                    service_time_point(loc) = service_time_point(loc)+1;
                    serverclock(si,loc) = myclock + service_time_RV(service_time_point(loc),loc);  % the time clock of next server finish                
                    finishclock(loc) = min(abs(serverclock(1:s(loc),loc)));
                    customer_rec(ID,1:3,2) = [myclock, loc, si];  % at time 'mylock', customer ID is in station 'loc' server 'si'
                    serverreg(si,loc) = ID;                       % regist in server                      
                else                      % join in the queue, finishclock not changed 
                    customer_rec(ID,1:3,2) = [myclock, loc, 0];   % at time 'mylock', customer ID is in station 'loc' queue
                    order_in_queue = state(loc) - s(loc);
                    queuereg(order_in_queue,loc) = ID;            % regist in queue
                end                                      
            end            
            inter_arrival_point(loc) = inter_arrival_point(loc)+1;        
            customerclock(loc) = myclock + inter_arrival_time_RV(inter_arrival_point(loc),loc);   % the time clock of next customer
          
        else               % some station finish
            
            [~, loc] = min(finishclock);  % find out the finish station
            [~, si] = min(abs(serverclock(1:s(loc),loc)));  % find out the finish server
            
            ID1 = serverreg(si,loc);            
            % If this is an unblocked customer, go to the known destination;
            % otherwise, randomly pick the destination
            if known_destination == 0
                P_bar = cumsum([P(loc,:) 1-sum(P(loc,:))]);  % find out the outgoing destination (based on probability)           
                goto_s = find(P_bar >= rand, 1);    % jump to some station or leave the system    
            else
                goto_s = known_destination;
                known_destination = 0;
            end
            
        % ++ case 2 ++ customer finish service and re-enter (will never be blocked!!!)    
            if goto_s == loc                  
                service_time_point(loc) = service_time_point(loc)+1;
                serverclock(si,loc) = myclock + service_time_RV(service_time_point(loc),loc);  % the time clock of next server finish
                finishclock(loc) = min(abs(serverclock(1:s(loc),loc)));     % update station 'loc' finish lock
                
                queue_l = state(loc) - s(loc);  % one customer in station 'loc' server 'si' goes to queue (end),
                if queue_l > 0                  % the queue head goes to server 'si'; otherwise no movement.                                       
                                                          
                    ID_depth = customer_rec(ID1,3,1)+1;
                    customer_rec(ID1,3,1) = ID_depth;                    
                    customer_rec(ID1,1:3,ID_depth) = [myclock, loc, 0];
                    
                    ID2 = queuereg(1,loc);
                    ID_depth = customer_rec(ID2,3,1)+1;
                    customer_rec(ID2,3,1) = ID_depth;                    
                    customer_rec(ID2,1:3,ID_depth) = [myclock, loc, si];                     
                    serverreg(si,loc) = ID2;
                    
                    if queue_l > 1
                        queuereg(1:queue_l-1,loc) = queuereg(2:queue_l,loc);                       
                    end
                    queuereg(queue_l,loc) = ID1;                
                end                
                
        % ++ case 3 ++ customer finish service and leave the system   
            elseif goto_s == J+1 
                
                ID_depth = customer_rec(ID1,3,1)+1;
                customer_rec(ID1,3,1) = ID_depth;                    
                customer_rec(ID1,1:3,ID_depth) = [myclock, -1, -1];  % -1 means leave the system
                
                % **** calculate the total sojourn time ****
                % **** and count the departure numbers *****           
                % <Choice A> calculate sojourn time in station
                if customer_rec(ID1,1,2) > T0 && myclock <= T
                    sojourn(:,J+1) = sojourn(:,J+1) + [myclock-customer_rec(ID1,1,2); 1]; % whole system
                    for station_i = 1:J
                        t_use = find(customer_rec(ID1,2,2:ID_depth) == station_i)+1; % if it is empty, +1 still gives empty
                        if ~isempty(t_use)
                            t_this = sum(customer_rec(ID1,1,t_use+1) - customer_rec(ID1,1,t_use));                        
                            sojourn(:,station_i) = sojourn(:,station_i) + [t_this; 1];
                        end
                    end                   
                end
                
                % <Choice B> calculate waiting time in queue
                if customer_rec(ID1,1,2) > T0 && myclock <= T                 
                    t_use = find(customer_rec(ID1,3,2:ID_depth) == 0)+1;
                    if ~isempty(t_use)
                        t_this = sum(customer_rec(ID1,1,t_use+1) - customer_rec(ID1,1,t_use));
                        waiting(:,J+1) = waiting(:,J+1) + [t_this; 1]; % waiting in system
                    else
                        waiting(:,J+1) = waiting(:,J+1) + [0; 1]; % NO waiting in system
                    end                  
                    for station_i = 1:J                     
                        enter_this = (customer_rec(ID1,2,2:ID_depth) == station_i);
                        if sum(enter_this) > 0 %%% bug fixed on 2019-05-17
                            queue_this = (customer_rec(ID1,3,2:ID_depth) == 0);
                            t_use = find(enter_this & queue_this)+1;
                            if ~isempty(t_use)
                                t_this = sum(customer_rec(ID1,1,t_use+1) - customer_rec(ID1,1,t_use));                        
                                waiting(:,station_i) = waiting(:,station_i) + [t_this; 1];
                            else
                                waiting(:,station_i) = waiting(:,station_i) + [0; 1]; % NO waiting in this station
                            end
                        end
                    end                   
                end              
                
                         
                % clear the customer_rec entry
                customer_rec(ID1,1:3,1:ID_depth) = 0;
                % ******************************************
             
                %------------ station(loc) successfully leave -------------
                queue_l = state(loc) - s(loc);
                state(loc) = state(loc)-1;
                if state(loc) < s(loc)  % this server will be empty (the queue was empty before)
                    serverclock(si,loc) = inf;
                    serverreg(si,loc) = 0;
                else                    % this server will be occupied by next customer
                    service_time_point(loc) = service_time_point(loc)+1;
                    serverclock(si,loc) = myclock + service_time_RV(service_time_point(loc),loc);  % the time clock of next server finish
                    
                    ID2 = queuereg(1,loc);
                    ID_depth = customer_rec(ID2,3,1)+1;
                    customer_rec(ID2,3,1) = ID_depth;                    
                    customer_rec(ID2,1:3,ID_depth) = [myclock, loc, si];                     
                    
                    serverreg(si,loc) = ID2;
                    if queue_l > 1
                        queuereg(1:queue_l-1,loc) = queuereg(2:queue_l,loc);                       
                    end
                    queuereg(queue_l,loc) = 0;
                end
                finishclock(loc) = min(abs(serverclock(1:s(loc),loc)));     % update station 'loc' finish lock 
      
                % It this station was full before, throw a block-release check
                if state(loc)+1 == K(loc)
                    block_open = loc;
                end
                %----------------------------------------------------------

        % ++ case 4 ++ customer finish service and "want" to jump into station goto_s   
            else  
                
                if state(goto_s) < K(goto_s)  % can jump                                                       
                    state(goto_s) = state(goto_s)+1;                    
                    ID_depth = customer_rec(ID1,3,1)+1;
                    customer_rec(ID1,3,1) = ID_depth;
                                       
                    if state(goto_s) <= s(goto_s)   % Not all servers were serving before, new server starts to work
                        goto_si = find(serverclock(1:s(goto_s),goto_s)==inf,1);  % assign an empty server               
                        service_time_point(goto_s) = service_time_point(goto_s)+1;
                        serverclock(goto_si,goto_s) = myclock + service_time_RV(service_time_point(goto_s),goto_s);  % the time clock of next server finish                   
                        finishclock(goto_s) = min(abs(serverclock(1:s(goto_s),goto_s)));   % update station 'goto_s' finish lock   
                        customer_rec(ID1,1:3,ID_depth) = [myclock, goto_s, goto_si]; % at time 'mylock', customer ID is in station 'goto_s' server 'goto_si'
                        serverreg(goto_si,goto_s) = ID1;                       % regist in server
                    else                      % join in the queue, finishclock not changed
                        customer_rec(ID1,1:3,ID_depth) = [myclock, goto_s, 0];       % at time 'mylock', customer ID is in station 'goto_s' queue
                        order_in_queue = state(goto_s) - s(goto_s);
                        queuereg(order_in_queue,goto_s) = ID1;            % regist in queue
                    end                                                                            
                    
                    %---------- station(loc) successfully leave -----------                    
                    queue_l = state(loc) - s(loc);
                    state(loc) = state(loc)-1;
                    if state(loc) < s(loc)  % this server will be empty
                        serverclock(si,loc) = inf;
                        serverreg(si,loc) = 0;
                    else                    % that server will be occupied by next customer
                        service_time_point(loc) = service_time_point(loc)+1;
                        serverclock(si,loc) = myclock + service_time_RV(service_time_point(loc),loc);  % the time clock of next server finish                   
                        
                        ID2 = queuereg(1,loc);
                        ID_depth = customer_rec(ID2,3,1)+1;
                        customer_rec(ID2,3,1) = ID_depth;                    
                        customer_rec(ID2,1:3,ID_depth) = [myclock, loc, si];                     

                        serverreg(si,loc) = ID2;
                        if queue_l > 1
                            queuereg(1:queue_l-1,loc) = queuereg(2:queue_l,loc);                       
                        end
                        queuereg(queue_l,loc) = 0;
                    end
                    finishclock(loc) = min(abs(serverclock(1:s(loc),loc)));     % update station 'loc' finish lock  
                                      
                    % It this station was full before, throw a block-release check
                    if state(loc)+1 == K(loc)
                        block_open = loc;
                    end                    
                    %------------------------------------------------------               
                    
                else   % can NOT jump, blocked by station 'goto_s' 
                    
                    %%% assign to the block list
                    %%% station 'goto_s' blocks station 'loc' with server 'si'
                    serverclock(si,loc) = -inf;     % The server is not working, but is still occupied (not set to 'inf')                
                    BlockList{goto_s} = [BlockList{goto_s}; loc si];
                    finishclock(loc) = min(abs(serverclock(1:s(loc),loc)));     % update station 'loc' finish lock                    
                    
                    %%% check weather there is a dead lock. If so, swap                 
                    %%% find ALL loop contains loc -> goto_s
                    pli = 1;
                    loop_dead = []; % To store ALL dead lock loop
                    for li = 1:size(CircleList,2)
                        loop = CircleList{li};
                        nod1 = find(loop == loc, 1);
                        if ~isempty(nod1) && loop(nod1+1) == goto_s   % this is a loop contains loc -> goto_s                                                           
                            % check if there is dead lock
                            block_flag = 1;
                            for lj = 2:length(loop)                                  
                                if isempty(BlockList{loop(lj)}) || isempty(find(BlockList{loop(lj)}(:,1) == loop(lj-1), 1))
                                    block_flag = 0;  % one edge is not blocked, the whole loop is not
                                    break
                                end
                            end
                            if block_flag == 1
                                loop_dead{pli} = loop;
                                pli = pli+1;
                            end                          
                        end
                    end
                    
                    if ~isempty(loop_dead)
                        if size(loop_dead,2) > 1
                            % randomly pick one dead lock loop
                            picki = randi(size(loop_dead,2));
                        else
                            picki = 1;
                        end
                        loop_dead = loop_dead{picki};
                        
                        %%% do the swap for this chosen loop
                        %%% first blocked first released
                        loopl = length(loop_dead);
                        sta_ser = zeros(loopl,3);
                        for lj = 2:loopl
                            down_station = loop_dead(lj);
                            up_station = loop_dead(lj-1);                        
                            up = find(BlockList{down_station}(:,1) == up_station ,1);
                            up_server = BlockList{down_station}(up,2);
                            sta_ser(lj-1,:) = [up_station, up_server, serverreg(up_server,up_station)];  % also add the active ID
                            BlockList{down_station}(up,:) = [];             % remove from the Block list
                        end
                        sta_ser(loopl,:) = sta_ser(1,:);
                        
                        % station sta_ser(.,1) with server sta_ser(.,2) take new customer
                        for lj = 1:loopl-1
                            service_time_point(sta_ser(lj,1)) = service_time_point(sta_ser(lj,1))+1;                        
                            serverclock(sta_ser(lj,2),sta_ser(lj,1)) = myclock + ...
                                service_time_RV(service_time_point(sta_ser(lj,1)),sta_ser(lj,1));                           
                            finishclock(sta_ser(lj,1)) = min(abs(serverclock(1:s(sta_ser(lj,1)),sta_ser(lj,1))));
                        end
                        
                        %%% update customer_rec, serverreg, queuereg       
                        for lj = 1:loopl-1
                            % update the customer_rec
                            ID_depth = customer_rec(sta_ser(lj,3),3,1)+1;    % sta_ser(lj,3) is the ID
                            customer_rec(sta_ser(lj,3),3,1) = ID_depth;
                            
                            % if the destination has no queue, join the server immediately; otherwise joint the queue
                            if state(sta_ser(lj+1,1)) <= s(sta_ser(lj+1,1))
                                customer_rec(sta_ser(lj,3),1:3,ID_depth) = [myclock, sta_ser(lj+1,1), sta_ser(lj+1,2)]; 
                            else
                                customer_rec(sta_ser(lj,3),1:3,ID_depth) = [myclock, sta_ser(lj+1,1), 0];
                            end                                                                                      
                            
                            % update serverreg, queuereg
                            if lj == 1
                                comingID = sta_ser(loopl-1,3);
                            else
                                comingID = sta_ser(lj-1,3);
                            end
                            queue_l = state(sta_ser(lj,1)) - s(sta_ser(lj,1));
                            if queue_l > 0  %%% has a queue                           
                                ID2 = queuereg(1,sta_ser(lj,1));
                                ID_depth = customer_rec(ID2,3,1)+1;
                                customer_rec(ID2,3,1) = ID_depth;
                                customer_rec(ID2,1:3,ID_depth) = [myclock, sta_ser(lj,1), sta_ser(lj,2)];                                
                                serverreg(sta_ser(lj,2), sta_ser(lj,1)) = ID2;
                                
                                if queue_l > 1
                                    queuereg(1:queue_l-1,sta_ser(lj,1)) = queuereg(2:queue_l,sta_ser(lj,1));                                
                                end
                                queuereg(queue_l,sta_ser(lj,1)) = comingID;                           
                            else           %%% has no queue & won't have a queue
                                % easy, customer sta_ser(lj-1,3) enter station sta_ser(lj,1) server sta_ser(lj,2)
                                serverreg(sta_ser(lj,2), sta_ser(lj,1)) = comingID;
                            end
                        end                      
                    end 
                end
            end
        % ++ end of case ++            
        end
        
        rec_index = rec_index+1;
        clock_rec(rec_index) = myclock;
        state_rec(rec_index,:) = state;             
        
        % +++++++++++       refresh RV pool when necessary      +++++++++++
        [ap_max, j] = max(inter_arrival_point);
        if ap_max == RV_n  % some station reaches the end of pool
            inter_arrival_time_RV(:,j) = inter_arrival_time(j,RV_n,lam);
            inter_arrival_point(j) = 0;
        end       
        [sp_max, j] = max(service_time_point);
        if sp_max == RV_n
            service_time_RV(:,j) = service_time(j,RV_n,mu);
            service_time_point(j) = 0;
        end
        % +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
        %%% enlarge clock_rec, state_rec when necessary
        if rec_index == pre_size           
            clock_rec = [clock_rec; zeros(RV_n,1)];            
            if max(K) < 256
                state_rec = [state_rec; uint8(zeros(RV_n,J))];
            else
                state_rec = [state_rec; zeros(RV_n,J)];
            end                 
            pre_size = pre_size + RV_n;        
        end
        
        end
        
    end
    % only keep the valid record
    clock_rec = clock_rec(1:rec_index);  
    state_rec = state_rec(1:rec_index,:);  
    
    %%% record 1
    %%% keep record of state at time point T, not some T1>T
    clockn = length(clock_rec);
    clock_end = clock_rec(clockn);
    while clock_rec(clockn) == clock_end
        clockn = clockn-1;
    end
    state_at_T(repi,:) = state_rec(clockn,:);
    
    %%% record 2
    %%% keep record of average time for each station and whole system <for thoese EVER enters!!!>
    time_sojourn_record(repi,1:J+1) = sojourn(1,:) ./ sojourn(2,:);    
    time_waiting_record(repi,1:J+1) = waiting(1,:) ./ waiting(2,:);  
    
    %%% record 3
    %%% keep record of average customer # in each station and whole system
    a = length(clock_rec);    
    % throw the warmup length
    h0 = find(clock_rec > T0,1);
    clock_rec = [T0; clock_rec(h0:a)];   % to be accurate, the interested time point is right at warmup_length    
    state_rec = state_rec(h0-1:a-1,:);      
    
    a = length(clock_rec);   
    inter_rec = clock_rec(2:a-1) - clock_rec(1:a-2);
    inter_rec(a-1) = T - clock_rec(a-1);
    num_record(repi,J+1) = inter_rec' * (sum(state_rec,2)) / (T-T0);       
    % station 1 to J
    for i = 1:J
        num_record(repi,i) = inter_rec' * double(state_rec(:,i)) / (T-T0);
    end      

    %%% keep record of average customer # waiting in each station queue and whole system
    queue_rec = max(double(state_rec) - repmat(s,size(state_rec,1),1), 0);
    num_record_queue(repi,J+1) = inter_rec' * (sum(queue_rec,2)) / (T-T0);
    for i = 1:J
        num_record_queue(repi,i) = inter_rec' * queue_rec(:,i) / (T-T0);
    end      
end
% toc


% [1] Simulated stationary distribution
% <require large simu_replication>
SimP = cell(1,J);
for j = 1:J
    for i=1:simR
        pn = state_at_T(i,j)+1;
        if pn > length(SimP{j})
            SimP{j}(pn) = 1;
        else
            SimP{j}(pn) = SimP{j}(pn) + 1;
        end
    end
    SimP{j} = SimP{j} / simR;
end

% [2] Simulated Expected customer # in the system
% <require either large simu_t_length or large simu_replication>
SimN_var = [mean(num_record); var(num_record) / simR];

% [3] Simulated Expected customer # in the queue (waiting)
% <require either large simu_t_length or large simu_replication>
SimQ_var = [mean(num_record_queue); var(num_record_queue) / simR];

% [4] Simulated Expected sojourn time in each station and whole system <for thoese ever enters>
% <require either large simu_t_length or large simu_replication>
SimT_var = [mean(time_sojourn_record); var(time_sojourn_record) / simR];

% [5] Simulated Expected waiting time in each station and whole system <for thoese ever enters>
% <require either large simu_t_length or large simu_replication>
SimW_var = [mean(time_waiting_record); var(time_waiting_record) / simR];