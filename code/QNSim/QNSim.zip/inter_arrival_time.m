function X = inter_arrival_time(j,n,lam)
% Generate n inter arrival times for station j [n x 1 vector]

% Example:
% arrival follows Poisson process with rate lam, i.e., inter arrival time
% follows exponential distribution with mean 1/lam 
if lam(j) ~= 0
    X = exprnd(1/lam(j),n,1);    % EXP, E[X] = 1/lam
else
    X = inf(n,1);
end

% You own distribution:
% ...

end