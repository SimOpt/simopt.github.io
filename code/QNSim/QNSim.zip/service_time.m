function X = service_time(j,n,mu)
% Generate n service times for station j [n x 1 vector]

% Example:
% for station 1 and 2, service time follows exponential distribution with 
% rate mu (mean 1/mu); for station 3, uniform[0.5, 2]
if j == 3
    X = rand(n,1)*1.5 + 0.5;
else
    if mu(j) ~= 0
        X = exprnd(1/mu(j),n,1);               % EXP, E[X] = 1/mu
    else
        X = inf(n,1);
    end
end

% You own distribution:
% ...

end