clear, clc; close all

%%% ====================== Specify your problem here ======================
% -- Step 1: --
% Specify the interarrival distribution in "inter_arrival_time.m"
% Specify the service distribution in "service_time.m"

% -- Step 2: --
% Set queueing network parameters
J = 3; % station number
lam = [4 0.4 0.4]; % arrival rate, always required, since it will be used
                   % to pre-allocate space for some array
s = [2 2 3]; % server number
mu = [0.6 1 0.8]; % service rate, not always required, depends on how you
                  % specify the "service_time.m"
K = [4 4 3];  % capacity                
P = [ 0 0.7 0.2 ; ... % transition probability matrix
      0   0 0.4 ; ...
      0 0.4 0.1 ];
  
% -- Step 3: --
% Set simulation parameter
T = 1000; % run length
T0 = 0.01*T; % warm-up length
simR = 500; % replication number
random_seed = 0; % random seed
%%% =======================================================================  
  

% find all the closed loop in the network
% use a third-party function "find_elem_circuits.m"
% author: Chris Maes  https://gist.github.com/cmaes/1260153
% moreover, the function "find_elem_circuits.m" relies on a function
% "components", which is a function in the graph package MatlabBGL
% author: David Gleich  http://dgleich.github.io/matlab-bgl 
Q = (P~=0);
addpath ./third_party_function
addpath ./third_party_function/matlab_bgl_4.0.1_private             
[CircleN,CircleList] =  find_elem_circuits(Q);

% Group parameters into SimPra and QueuePra
SimPra.seed = 0;  % random seed
SimPra.T = T;
SimPra.T0 = T0;
SimPra.simR = simR;
QueuePra.J = J;
QueuePra.lam = lam;
QueuePra.s = s;
QueuePra.mu = mu;
QueuePra.P = P;
QueuePra.K = K;
QueuePra.CircleList = CircleList;

% Run the simulator
% Outputs:
% SimP - stationary distribution for each station
% SimN_var - averaged number of customers in each station & the whole system
%            and the variance of the AVERAGED number
% SimQ_var - averaged number of customers in queue of each station & the
%            whole system (waiting) and the variance of the AVERAGED number
% SimT_var - averaged sojourn time in each station & the whole system
%            and the variance of the AVERAGED number
% SimW_var - averaged waiting time in queue of each station & the whole system
%            and the variance of the AVERAGED number
% See more description in "QN_GGsK_BAS_FIFO.m"
[SimP, SimN_var, SimQ_var, SimT_var, SimW_var] = QN_GGsK_BAS_FIFO(SimPra, QueuePra);

% Draw the stationary distribution (Discrete Probability) for each station
% <require large number of simulation replication>
figure,
for i=1:J
	subplot(ceil(J/3),3,i);
    plot(0:length(SimP{i})-1, SimP{i},'s');
    title(['Station ' num2str(i)]);
end