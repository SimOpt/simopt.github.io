SOURCE:
These codes are originally downloaded from https://simopt.github.io/QNSim



COMPATIBILITY:
These codes were written and tested in MATLAB R2015a.



LICENSE:
Redistribution and use in source and binary forms, with or without modification,
are permitted, under the terms of the BSD license. See the LICENSE.txt file for
details.



WARNING:
These codes are written only for the purpose of demonstration and verification.
While the correctness has been carefully checked, the quality such as
standardability, clarity, generality, and efficiency may have not been well
considered.



Please report any erros to shenhaihui@gmail.com