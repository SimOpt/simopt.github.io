% Example for Stochastic Kriging with Gradient (SKG)
% queue length of M/G/1 (excluding the customer in service)
% arrival rate is x
% service time ~ gamma dist with shape 1/2 and rate 1/2.

% Note:
% (1) for simplicity, the simulation for M/G/1 queue is mimicked by the
% theoretical true value plus appropriate noise.
% (2) gradient is estimated using central finite-difference.

% k - number of design points
% d - dimension of design points
% X - design points (k x d) 
% n - (k x 1) vector, ni=[n1; n2; ..., nk], replication number
% Ycell - (k x 1) cell, each is a (1 x ni) vector, containing ni replications of Y
% Dcell - (k x 1) cell, each is a (d x ni) matrix about a points.
%          row 1, deriative wrt 1st coordinate for ni replications, ..., 
%          row d, deriative wrt d-th coordinate for ni replications

clear; clc; close all

k = 5; % number of design points
d = 1; % dimension of design points

%%% Predicted points
XK = (0.01:0.01:0.99)';

% the true curve
y_true = 1.5 * XK.^2 ./ (1-XK);

%%% Observed points
X = [0.2; 0.4; 0.6; 0.8; 0.86];
% true value
Y = 1.5 * X.^2 ./ (1-X);

% add artificial noise
% for reproducibility, arbitrarily fix a random seed
s = RandStream('mt19937ar','Seed',22);
RandStream.setGlobalStream(s);

% appropriate noise for certain simulation setting
T = 2500; % simulation length
N = 50; % replication number

noise_var = 1/4 * X.*(20+121*X-116*X.^2+29*X.^3) ./ (1-X).^4 /T;
noise = randn(length(X),N);
for i=1:length(X)
    noise(i,:) = noise(i,:) * sqrt(noise_var(i));   
end

% observation of response, in cell form
Ycell = cell(k,1);
for i = 1:k
    Ycell{i} = Y(i) + noise(i,:);
end
% observation of response
Y = Y + mean(noise,2);

% observation of gradient, in cell form
Dcell = cell(k,1);
%%% gradient is estimated using central finite-difference estimator.
%%% forward finite-difference estimator is too inaccurate
Xa = X - 0.01; % left points
Ya = 1.5 * Xa.^2 ./ (1-Xa); % true value
noise_var = 1/4 * Xa.*(20+121*Xa-116*Xa.^2+29*Xa.^3) ./ (1-Xa).^4 /T;
noise = randn(length(Xa),N);
for i=1:length(Xa)
    noise(i,:) = noise(i,:) * sqrt(noise_var(i));   
end
Ycella = cell(k,1); % observation of response
for i = 1:k
    Ycella{i} = Ya(i) + noise(i,:);
end
Xb = X + 0.01; % right points
Yb = 1.5 * Xb.^2 ./ (1-Xb); % true value
noise_var = 1/4 * Xb.*(20+121*Xb-116*Xb.^2+29*Xb.^3) ./ (1-Xb).^4 /T;
noise = randn(length(Xb),N);
for i=1:length(Xb)
    noise(i,:) = noise(i,:) * sqrt(noise_var(i));   
end
Ycellb = cell(k,1); % observation of response
for i = 1:k
    Ycellb{i} = Yb(i) + noise(i,:);
end
% CFD estimator of gradient
for i = 1:k
    Dcell{i} = (Ycellb{i} - Ycella{i}) / 0.02;
end


% if consider constant trend term
B = [ones(k,1); zeros(d*k,1)];
K = size(XK,1);
BK = ones(K,1);

% === >>> SKG fit and predict:
skriging_model = SKGfit(X,Ycell,Dcell,B);
[SKG, MSE] = SKGpredict(skriging_model,XK,BK);

% === >>> plot SKG fitted surface:
figure;
set (gcf,'Position',[500,500,520,350])
plot(XK,y_true,'-','LineWidth',1,'Color',[31,119,180]/255); hold on;
plot(X,Y,'o','Color',[255,127,14]/255);
plot(XK,SKG,'k--','LineWidth',1);
% MSE
plot(XK,SKG+1.96*sqrt(MSE),':','LineWidth',0.8,'Color',[214,39,40]/255);
h1 = plot(XK,SKG-1.96*sqrt(MSE),':','LineWidth',0.8,'Color',[214,39,40]/255); 

% figure format
axis([0 1 -1 11]);
xlabel('Arrival rate $x$','Interpreter','latex');
ylabel('Expected queue length','Interpreter','latex');
set(gca,'YTick',[0 2 4 6 8 10])
set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
ht = legend({'True surface','Mean simulation output',...
    'Fitted surface of GESK (with gradient)','$\pm 1.96 \sqrt{\widehat{\mathrm{MSE}}}$ intervals',...
    },'Location','northwest');

set(ht,'Interpreter','latex','color','none'); % 'FontSize',10